extends CharacterBody3D

const MOVE_SPEED: float = 8.0
const JUMP_VELOCITY: float = 7.0  # Jump strength
const GRAVITY: float = 24.0  # Gravity strength
const LANES: Array = [-1.7, 0, 1.7]  # Lane positions on x-axis

var starting_point: Vector3 = Vector3.ZERO
var current_lane: int = 1  # Start at lane index 1 (x = 0)
var target_lane: int = 1
var max_health: int = 100
var health: int = 100


var is_jumping: bool = false
var is_dead: bool = false
signal hit


func die() -> void:
	is_dead = true
	# Informa il Main che il giocatore è morto
	get_parent()._on_giocatore_dead()
	
func update_health_bar() -> void:
	$SubViewport/ProgressBar.value = health


func take_damage(damage: int) -> void:
	if is_dead:
		return
	
	health -= damage
	health = clamp(health, 0, max_health)
	update_health_bar()

	if health == 0:
		die()




func _ready() -> void:
	starting_point = global_transform.origin

func _physics_process(delta: float) -> void:
	
	# Handle lane switching
	if Input.is_action_just_pressed("ui_right") and target_lane > 0:
		target_lane -= 1
	if Input.is_action_just_pressed("ui_left") and target_lane < LANES.size() - 1:
		target_lane += 1
	
	# Move towards the target lane
	var target_x: float = LANES[target_lane]
	var current_x: float = global_transform.origin.x
	global_transform.origin.x = lerp(current_x, target_x, MOVE_SPEED * delta)

	# Apply gravity
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0  # Reset vertical velocity when on the floor

	# Jumping logic
	if is_on_floor() and (Input.is_action_pressed("ui_up") or Input.is_action_pressed("ui_accept")):
		velocity.y = JUMP_VELOCITY  # Apply jump velocity

	# Apply the velocity and move the character
	move_and_slide()

	# Play animations based on movement
	if not is_on_floor():
		$kid/AnimationPlayer.play("Run")
	else:
		$kid/AnimationPlayer.play("Run")


func _on_area_3d_body_entered(body: Node3D) -> void:
	hit.emit()
	
