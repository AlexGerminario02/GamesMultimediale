extends CharacterBody3D

const SPEED: float = 5

func _physics_process(delta: float) -> void:
	# Apply gravity
	if not is_on_floor():
		velocity += get_gravity() * delta
	velocity.z = -SPEED 

	# Apply the velocity and move the character
	move_and_slide()
	if position.z < -1:
		queue_free()
