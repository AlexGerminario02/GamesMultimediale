extends Node

@export var obstacles : Array[PackedScene]
@export var explosion : PackedScene

func _on_timer_timeout() -> void:
	var obs = obstacles.pick_random()
	var obstacleIns = obs.instantiate()
	obstacleIns.position=Vector3(random(),0.25,28)
	if obstacleIns.name == "knife":
		obstacleIns.position.y= 0
	add_child(obstacleIns)
	
func random():
	if randi_range(1,3) == 1:
		return -1.7
	else: 
		if randi_range(1,3) == 2:
			return 0
		else:
			return 1.7


func _on_giocatore_hit() -> void:
	$Giocatore.take_damage(20)

func _on_giocatore_dead() -> void:
	var expl = explosion.instantiate()
	expl.position = $Giocatore.position
	add_child(expl)
	expl.emitting = true
	$Giocatore.queue_free()
	await get_tree().create_timer(2).timeout
	get_tree().reload_current_scene()
